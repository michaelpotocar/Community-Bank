import { handler } from "./index.mjs";

handler();